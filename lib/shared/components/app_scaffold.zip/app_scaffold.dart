import 'dart:ui';

import 'package:arpico_iam/aiam.dart';
import 'package:flutter/material.dart';

class AppLoaders {
  AppLoaders._();
  static final instance = AppLoaders._();

  final ValueNotifier<bool> loading = ValueNotifier(false);

  void show() => loading.value = true;
  void hide() => loading.value = false;
}

class AppScaffolds extends StatelessWidget {
  final String title;
  final Widget? body;
  final Widget? child;
  final ScrollController? controller;
  final Color? backgroundColor;
  final Widget? bottomSheet;
  final Widget? bottomNavigationBar;
  final bool? resizeToAvoidBottomInset;
  final Widget? bottomSheetBuilder;
  final Stack? stack;
  final List<Widget>? actions;
  final AppBar? appBar;
  final bool isLoading;
  final Widget? emptyWidget;

  const AppScaffolds({
    super.key,
    required this.title,
    this.body,
    this.child,
    this.controller,
    this.backgroundColor,
    this.bottomSheet,
    this.resizeToAvoidBottomInset,
    this.bottomNavigationBar,
    this.bottomSheetBuilder,
    this.stack,
    this.actions,
    this.appBar,
    this.isLoading = false,
    this.emptyWidget
  });

  @override
  Widget build(BuildContext context) {
    final Widget thisBody = body ?? Center(child: Text('[ $title ] screen'));

    return PopScope(
      onPopInvokedWithResult: (can, result){
        print('go back');
      },
      child: ValueListenableBuilder<bool>(
        valueListenable: AppLoaders.instance.loading,
        builder: (_, loading, __) {
          return Material(
            child: Stack(
              children: [
                Scaffold(
                  backgroundColor: backgroundColor,
                  appBar: AppBar(
                    title: Text(title),
                    forceMaterialTransparency: true,
                    actions: actions,
                  ),
                  body: isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : Stack(
                          fit: StackFit.expand,
                          children: [
                            child ??
                                SingleChildScrollView(
                                  controller: controller,
                                  child: thisBody,
                                ),
                            bottomSheetBuilder ?? SizedBox.shrink(),
                          ],
                        ),
                  bottomSheet: bottomSheet,
                  resizeToAvoidBottomInset: resizeToAvoidBottomInset,
                  bottomNavigationBar: bottomNavigationBar,
                ),
                if (loading) BlurLoader(),
              ],
            ),
          );
        },
      ),
    );
  }
}

